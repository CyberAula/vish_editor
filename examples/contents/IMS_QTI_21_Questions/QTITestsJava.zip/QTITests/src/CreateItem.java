import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.qtitools.qti.node.content.ItemBody;
import org.qtitools.qti.node.content.basic.TextRun;
import org.qtitools.qti.node.content.xhtml.text.Div;
import org.qtitools.qti.node.content.xhtml.text.P;
import org.qtitools.qti.node.expression.general.BaseValue;
import org.qtitools.qti.node.expression.general.Variable;
import org.qtitools.qti.node.expression.operator.Gte;
import org.qtitools.qti.node.item.AssessmentItem;
import org.qtitools.qti.node.item.interaction.SliderInteraction;
import org.qtitools.qti.node.item.response.declaration.ResponseDeclaration;
import org.qtitools.qti.node.item.response.processing.ResponseCondition;
import org.qtitools.qti.node.item.response.processing.ResponseIf;
import org.qtitools.qti.node.item.response.processing.ResponseProcessing;
import org.qtitools.qti.node.item.response.processing.SetOutcomeValue;
import org.qtitools.qti.node.outcome.declaration.OutcomeDeclaration;
import org.qtitools.qti.node.shared.FieldValue;
import org.qtitools.qti.node.shared.declaration.DefaultValue;
import org.qtitools.qti.value.BaseType;
import org.qtitools.qti.value.Cardinality;
import org.qtitools.qti.value.IntegerValue;

/**
 * Demonstrates how to programmatically create a new item
 * 
 * @author Jonathon Hare
 */
public class CreateItem {

	public static void main(String[] args) {
		//create an assessment item
		AssessmentItem assessmentItem = new AssessmentItem("my-test-item", "Jon's demonstration item", false, false);
		
		//add response declaration
		ResponseDeclaration responseDeclaration = new ResponseDeclaration(assessmentItem);
		responseDeclaration.setIdentifier("response1");
		responseDeclaration.setBaseType(BaseType.INTEGER);
		responseDeclaration.setCardinality(Cardinality.SINGLE);
		assessmentItem.getResponseDeclarations().add(responseDeclaration);
		
		//add outcome declaration
		OutcomeDeclaration outcomeDeclaration = new OutcomeDeclaration(assessmentItem);
		outcomeDeclaration.setIdentifier("SCORE");
		outcomeDeclaration.setBaseType(BaseType.INTEGER);
		outcomeDeclaration.setCardinality(Cardinality.SINGLE);
		assessmentItem.getOutcomeDeclarations().add(outcomeDeclaration);
		
		//set the default SCORE to 0
		DefaultValue defaultValue = new DefaultValue(outcomeDeclaration);
		FieldValue fieldValue = new FieldValue(defaultValue);
		fieldValue.setSingleValue(new IntegerValue(0));
		defaultValue.getFieldValues().add(fieldValue);
		outcomeDeclaration.setDefaultValue(defaultValue);
		
		//add item body
		ItemBody itemBody = new ItemBody(assessmentItem);
		assessmentItem.setItemBody(itemBody);

		//add a div to the body
		Div div = new Div(itemBody);
		itemBody.appendChild(div);
		
		//add a paragraph to the div
		P p = new P(div);
		p.appendChild(new TextRun(p, "Hello world"));
		div.appendChild(p);
		
		//add a sliderInteraction to the div
		SliderInteraction sliderInteraction = new SliderInteraction(div);
		sliderInteraction.setLowerBound(0.0);
		sliderInteraction.setUpperBound(100.0);
		sliderInteraction.setResponseIdentifier("response1");
		div.appendChild(sliderInteraction);
		
		//add ResponseProcessing
		ResponseProcessing responseProcessing = new ResponseProcessing(assessmentItem);
		ResponseCondition responseCondition = new ResponseCondition(responseProcessing);
		assessmentItem.setResponseProcessing(responseProcessing);
		responseProcessing.getResponseRules().add(responseCondition);
		
		ResponseIf responseIf = new ResponseIf(responseCondition);
		responseCondition.setResponseIf(responseIf);
		
		Gte gte = new Gte(responseIf);
		responseIf.setExpression(gte);

		Variable variable = new Variable(gte);
		variable.setIdentifier("response1");
		gte.getChildren().add(variable);

		BaseValue bv = new BaseValue(gte);
		bv.setBaseTypeAttrValue(BaseType.INTEGER);
		bv.setSingleValue(new IntegerValue(50));
		gte.getChildren().add(bv);
		
		SetOutcomeValue setOutcomeValue = new SetOutcomeValue(responseIf);
		responseIf.getResponseRules().add(setOutcomeValue);
		setOutcomeValue.setIdentifier("SCORE");
		BaseValue score = new BaseValue(gte);
		score.setBaseTypeAttrValue(BaseType.INTEGER);
		score.setSingleValue(new IntegerValue(1));
		setOutcomeValue.setExpression(score);
		
		//If there are any errors, then print a validation report, otherwise print the item as xml
		if (assessmentItem.validate().getAllItems().size() == 0) 
		{
			System.out.println(assessmentItem.toXmlString());
		} else {
			System.out.println(assessmentItem.validate());
		}
		
		//now test the item
		assessmentItem.initialize(null);
		Map<String, List<String>> responses = new HashMap<String, List<String>>();
		
		//set response to 30
		responses.put("response1", Arrays.asList(new String [] {"30"}));
		assessmentItem.setResponses(responses);
		assessmentItem.processResponses();
		System.out.println(assessmentItem.getOutcomeValue("SCORE")); //should print 0 as 30 < 50
		
		//set response to 70
		assessmentItem.initialize(null); //re-init to defaults
		responses.put("response1", Arrays.asList(new String [] {"70"}));
		assessmentItem.setResponses(responses);
		assessmentItem.processResponses();
		System.out.println(assessmentItem.getOutcomeValue("SCORE")); //should print 1 as 70 >= 50
	}
}