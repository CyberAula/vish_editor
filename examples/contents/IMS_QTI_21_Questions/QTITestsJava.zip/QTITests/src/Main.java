import org.qtitools.qti.node.test.AssessmentItemRef;
import org.qtitools.qti.node.test.AssessmentSection;
import org.qtitools.qti.node.test.AssessmentTest;
import org.qtitools.qti.node.test.TestPart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AssessmentTest test = new AssessmentTest(); 
		TestPart tp = new TestPart(test); 
		test.getTestParts().add(tp);
		AssessmentSection section = new AssessmentSection(tp); 
		tp.getAssessmentSections().add(section); 
		AssessmentItemRef air = new AssessmentItemRef(section); 
		section.getChildren().add(air);
		air.setHref("myitem.xml");
		System.out.println(test.validate());
		System.out.println(test.toXmlString());
	}

}
